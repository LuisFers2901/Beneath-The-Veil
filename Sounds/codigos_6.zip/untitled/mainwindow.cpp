#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->widget->setVisible(false);
    ui->groupBox->setVisible(false);
    ui->widget->setGeometry(ui->Group1->x(),ui->Group1->y(),
                            ui->widget->width(),ui->widget->height());
    pn= new pantalla1;
    time = new QTimer;
    connect(time,SIGNAL(timeout()),this,SLOT(mover_elemento()));
    ax = 0;
    ay = 10;
    x = ui->comboBox->x();
    y =  ui->comboBox->y();
    vx = 20;
    vy = -30;
    T = 0.1;
    f = 5;
}

MainWindow::~MainWindow()
{
    delete ui;
    delete pn;
    delete time;
}


void MainWindow::on_comboBox_currentIndexChanged(int index)
{
    ui->Group1->setVisible(index==0);
    ui->widget->setVisible(index==1);
}

void MainWindow::on_pushButton_2_clicked()
{
    time->start(T*1000);

}

void MainWindow::mover_elemento()
{
    calcular_cinematica();
    ui->comboBox->setGeometry(x,y,
                              ui->comboBox->width(),ui->comboBox->height());
}

void MainWindow::calcular_cinematica()
{
    vx += ax*T*f;
    vy += ay*T*f;
    x += vx*T*f;
    y += vy*T*f;
}
