#include "pantalla1.h"
#include "ui_pantalla1.h"

pantalla1::pantalla1(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::pantalla1)
{
    ui->setupUi(this);
}

pantalla1::~pantalla1()
{
    delete ui;
}
