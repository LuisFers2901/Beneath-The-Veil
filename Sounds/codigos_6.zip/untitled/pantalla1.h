#ifndef PANTALLA1_H
#define PANTALLA1_H

#include <QWidget>

namespace Ui {
class pantalla1;
}

class pantalla1 : public QWidget
{
    Q_OBJECT

public:
    explicit pantalla1(QWidget *parent = nullptr);
    ~pantalla1();

private:
    Ui::pantalla1 *ui;
};

#endif // PANTALLA1_H
