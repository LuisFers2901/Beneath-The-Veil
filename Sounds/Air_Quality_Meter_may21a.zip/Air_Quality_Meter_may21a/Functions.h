#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <Arduino.h>

void LEDColor(int ReadSensor, int ChannelLEDRed, int ChannelLEDGreen, int ChannelLEDBlue) {

  int Red = 255;
  int Green = 255;
  int Blue = 255;

  if (ReadSensor < 1020) {
    Red = 255;
    Green = -(ReadSensor/4) + 1020;
    Blue = 0;
  } else if (ReadSensor >= 1020 && ReadSensor < 2040) {
    Red = -(ReadSensor/4) + 510;
    Green = 0;
    Blue = 0;
  } else if (ReadSensor >= 2040 && ReadSensor < 3060) {
    Red = 0;
    Green = 0;
    Blue = (ReadSensor/4) - 510;
  } else if (ReadSensor >= 3060) {
    Red = 0;

      if (ReadSensor >= 4080) {
        Green = 255;
      } else {
        Green = (ReadSensor)/4;
      }

    Blue = 255;
  }

  if (ChannelLEDRed != -1){
    ledcWrite(ChannelLEDRed, Red);
  }
  if (ChannelLEDGreen != -1){
    ledcWrite(ChannelLEDGreen, Green);
  }
  if (ChannelLEDBlue != -1){
    ledcWrite(ChannelLEDBlue, Blue);
  }
  
}

#endif