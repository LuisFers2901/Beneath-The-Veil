#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent):
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QScreen* primaryScreen = QApplication::primaryScreen();
    QRect Desktop = primaryScreen->geometry();
//    showFullScreen();
    DesktopX = Desktop.x();
    DesktopY = Desktop.y();
    DesktopWidth = Desktop.width();
    DesktopHeight = Desktop.height();
    UIWidth = ui->graphicsView->width()-2;
    UIHeight = ui->graphicsView->height()-2;

    MainMenu = new QGraphicsScene();
    Cage = new QGraphicsScene();

    MainMenu->setSceneRect(DesktopX, DesktopY, UIWidth, UIHeight);
    Cage->setSceneRect(DesktopX, DesktopY, UIWidth, UIHeight);

    int Option = 2;

//    switch (Option) {
//    case 1:
//        setStyleSheet("background-image: url(:/Images/Menu Temp.png); "
//                      "background-position: center; "
//                      "background-repeat: no-repeat; "
//                      "background-size: cover;");
//        break;
//    case 2:
//        setStyleSheet("background-image: url(:/Images/Pantalla Inicio Temporal.png); "
////                      "background-position: center; "
//                      "background-repeat: no-repeat; ");
//        break;
//    }




}

Widget::~Widget()
{
    delete ui;
}
